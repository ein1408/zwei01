<?php /*a:2:{s:67:"D:\phpstudy_pro\WWW\ein04\application\admin\view\bill\recharge.html";i:1587984752;s:63:"D:\phpstudy_pro\WWW\ein04\application\admin\view\base\base.html";i:1571729646;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo htmlentities($site_config['value']['title']); ?></title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="format-detection" content="telephone=no">
    <link rel="stylesheet" href="/layui/css/layui.css" media="all"/>
    <link rel="stylesheet" href="/css/public.css" media="all"/>
    
</head>
<body class="childrenBody">

<form class="layui-form">
    <blockquote class="layui-elem-quote quoteBox">
        <form class="layui-form">
            <div class="layui-inline">
                <div class="layui-input-inline">
                    <input type="text" class="layui-input searchVal" placeholder="请输入用户账号" />
                </div>
                <a class="layui-btn search_btn" data-type="reload">搜索</a>
            </div>
        </form>
    </blockquote>
    <table id="usersList" lay-filter="usersList"></table>
    <!--操作-->
    <script type="text/html" id="usersListBar">
        <a class="layui-btn layui-btn-xs" lay-event="edit">编辑</a>
        <a class="layui-btn layui-btn-xs" lay-event="plist">查看推广下级</a>
    </script>
</form>

<script type="text/javascript" src="/layui/layui.js"></script>

<script>
    layui.use(['form','layer','table'],function(){
        var form = layui.form,
            layer = parent.layer === undefined ? layui.layer : top.layer,
            $ = layui.jquery, table = layui.table;

        //用户列表
        var tableIns = table.render({
            elem: '#usersList',
            url : "<?php echo url('/admin/recharge'); ?>",
            cellMinWidth : 95,
            page : true,
            limit:10,
            limits:[5,10,15,20],
            height : "full-125",
            id:'usersListTable',
            cols : [[
                {field: 'id', title: 'id', width:60, align:"center"},
                {field: 'orderid', title: '订单号',  align:'center'},
                {field: 'account', title: '用户账号',align:"center"},
                {field: 'nickname', title: '昵称', align:'center'},
                {field: 'pm', title: '支付/获取',  align:'center'},
                {field: 'title', title: '标题',  align:'center'},
                {field: 'number', title: '金额',  align:'center'},
                {field: 'type', title: '类型',  align:'center'},
                {field: 'balance', title: '用户余额',  align:'center'},
                {field: 'add_time', title: '增加时间',  align:'center'},
                {field: 'status', title: '状态',  align:'center'},
                {
                    field: 'status', title: '是否通过', align: 'center', width: 100, templet: function (d) {
                        if (d.status == 1) {
                            return '<input type="checkbox" name="status"  checked="checked"  lay-filter="status" value="' + d.id + '" lay-skin="switch" lay-text="驳回|通过" ' + d.status + ' >'
                        } else {
                            return '<input type="checkbox" name="status" lay-filter="status" value="' + d.id + '" lay-skin="switch" lay-text="驳回|通过" ' + d.status + ' >'
                        }
                    }
                },
            ]]
        });

        //搜索【此功能需要后台配合，所以暂时没有动态效果演示】
        $(".search_btn").on("click",function(){
            table.reload("usersListTable",{
                page: {
                    curr: 1 //重新从第 1 页开始
                },
                where: {
                    key: $(".searchVal").val()  //搜索的关键字
                }
            })
        });
        //佣金审核
        form.on('switch(status)', function (data) {
            var index = layer.msg('修改中，请稍后', {icon: 16, time: false, shade: 0.8});
            setTimeout(function () {
                layer.close(index);
                var status = data.elem.checked ? 1 : 0;
                id = data.elem.value;
                $.post("<?php echo url('/admin/cash_withdrawal'); ?>", {id: id, status: status}, function (data) {
                    var icon = 5;
                    if (data.code) {
                        icon = 6;
                    }
                    layer.msg(data.msg, {icon: icon, time: 1500});
                });
            }, 500);
        });
   

    })
</script>

</body>
</html>