<?php /*a:2:{s:74:"D:\phpstudy_pro\WWW\ein04\application\admin\view\system\notice_config.html";i:1571729646;s:63:"D:\phpstudy_pro\WWW\ein04\application\admin\view\base\base.html";i:1571729646;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo htmlentities($site_config['value']['title']); ?></title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="format-detection" content="telephone=no">
    <link rel="stylesheet" href="/layui/css/layui.css" media="all"/>
    <link rel="stylesheet" href="/css/public.css" media="all"/>
    
</head>
<body class="childrenBody">

<fieldset class="layui-elem-field layui-field-title">
    <legend>公告管理</legend>
</fieldset>
<div class="layui-row layui-tab-content">
    <div class="layui-col-md12">
        <form class="layui-form layui-form-pane" action="">
            <div class="layui-form-item">
                <label class="layui-form-label">启用状态</label>
                <div class="layui-input-block">
                    <input type="checkbox" name="status" lay-skin="switch" lay-text="开启|关闭" value="1" <?php if($data['value']['status'] == '1'): ?>checked<?php endif; ?>>
                </div>
            </div>
            <div class="layui-form-item">
                <textarea id="notice" style="display: none;" name="notice"><?php echo htmlentities($data['value']['notice']); ?></textarea>
            </div>
            <div class="layui-form-item">
                <div class="layui-input-block">
                    <a class="layui-btn sync-text" lay-submit lay-filter="save">立即提交</a>
                </div>
            </div>
        </form>
    </div>
</div>



<script type="text/javascript" src="/layui/layui.js"></script>

<script>
    layui.use(['form', 'jquery','layer','layedit'], function () {
        var form = layui.form;
        var $ = layui.jquery;
        var layer = parent.layer === undefined ? layui.layer : top.layer;
        var layedit = layui.layedit;
        var tIndex = layedit.build('notice'); //建立编辑器
        
        $('.sync-text').on('click',function(){
            layedit.sync(tIndex); //同步编辑器文本到textarea
        });
        //监听提交
        form.on('submit(save)', function (data){
            var obj = $(this);
            obj.attr("disabled", "disabled").addClass("layui-disabled");
            $.post("<?php echo url('/admin/noticeConfig'); ?>", data.field, function (data) {
                var icon = 5;
                if (data.code) {
                    icon = 6;
                }
                layer.msg(data.msg, {icon: icon, time: 1500}, function () {
                    if (data.code) {
                        location.reload();
                    } else {
                        obj.removeAttr("disabled").removeClass("layui-disabled");
                    }
                });
            });
            return false;
        });
    });
</script>

</body>
</html>