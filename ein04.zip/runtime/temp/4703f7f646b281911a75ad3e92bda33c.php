<?php /*a:1:{s:65:"D:\phpstudy_pro\WWW\ein04\application\admin\view\login\login.html";i:1571729646;}*/ ?>
<!DOCTYPE html>
<html class="loginHtml">
<head>
    <meta charset="utf-8">
    <title>登录</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="format-detection" content="telephone=no">
    <link rel="icon" href="/favicon.ico">
    <link rel="stylesheet" href="/layui/css/layui.css" media="all"/>
    <link rel="stylesheet" href="/css/public.css" media="all"/>
</head>
<body class="loginBody">
<form class="layui-form" id="login-form">
    <div class="login_face"><img src="/images/face.jpg" class="userAvatar"></div>
    <div class="layui-form-item input-item">
        <label for="userName">用户名</label>
        <input type="text" placeholder="请输入用户名" autocomplete="off" id="userName" name="user" class="layui-input"
               lay-verify="required">
    </div>
    <div class="layui-form-item input-item">
        <label for="password">密码</label>
        <input type="password" placeholder="请输入密码" autocomplete="off" id="password" name="password" class="layui-input"
               lay-verify="required">
    </div>
    <?php if($is_open_captcha): ?>
    <div class="layui-form-item input-item" id="imgCode">
        <label for="code">验证码</label>
        <input type="text" placeholder="请输入验证码" autocomplete="off" id="code" name="code" class="layui-input"
               lay-verify="required">
        <img src="<?php echo url('/admin/verify'); ?>" width="116" height="36" id="captcha"
             onclick="this.src='<?php echo url('/admin/verify'); ?>';">
    </div>
    <?php endif; ?>

    <div class="layui-form-item " style="margin: 30px 0px">
        <button class="layui-btn layui-block" lay-filter="login" lay-submit>登录</button>
    </div>
</form>
<script type="text/javascript" src="/layui/layui.js"></script>
<script>
    layui.use(['form', 'layer', 'jquery'], function () {
        var form = layui.form,
            layer = parent.layer === undefined ? layui.layer : top.layer
        $ = layui.jquery;

        //登录按钮
        form.on("submit(login)", function (data) {
            var obj = $(this);
            var data = data.field;
            obj.text("登录中...").attr("disabled", "disabled").addClass("layui-disabled");
            $.ajax({
                url: "<?php echo url('/admin/login'); ?>",
                type: 'post',
                dataType: 'json',
                data: data,
                success: function (data) {
                    var time = 3000;
                    var icon = 5;
                    if (data.code) {
                        icon = 6;
                        time = 1000;
                    }
                    layer.msg(data.msg, {icon: icon,time: time}, function () {
                        if (data.code) {
                            location.href = data.url;
                        } else {
                            obj.text("登录").removeAttr("disabled").removeClass("layui-disabled");
                            <?php if($is_open_captcha): ?>
                                $('#captcha').attr('src', '<?php echo url('/admin/verify'); ?>');
                            <?php endif; ?>
                            $('#code').val('');
                        }
                    });

                },
                error: function (e) {
                    obj.text("登录").removeAttr("disabled").removeClass("layui-disabled");
                    layer.msg('登录错误，请检查配置是否正确', {icon: 5});
                }
            })
            return false;
        })

        //表单输入效果
        $(".loginBody .input-item").click(function (e) {
            e.stopPropagation();
            $(this).addClass("layui-input-focus").find(".layui-input").focus();
        })
        $(".loginBody .layui-form-item .layui-input").focus(function () {
            $(this).parent().addClass("layui-input-focus");
        })
        $(".loginBody .layui-form-item .layui-input").blur(function () {
            $(this).parent().removeClass("layui-input-focus");
            if ($(this).val() != '') {
                $(this).parent().addClass("layui-input-active");
            } else {
                $(this).parent().removeClass("layui-input-active");
            }
        })
    })
</script>
</body>
</html>