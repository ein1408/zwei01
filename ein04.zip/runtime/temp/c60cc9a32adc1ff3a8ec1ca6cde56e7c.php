<?php /*a:2:{s:72:"D:\phpstudy_pro\WWW\ein04\application\admin\view\user\member_parent.html";i:1587979655;s:63:"D:\phpstudy_pro\WWW\ein04\application\admin\view\base\base.html";i:1571729646;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo htmlentities($site_config['value']['title']); ?></title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="format-detection" content="telephone=no">
    <link rel="stylesheet" href="/layui/css/layui.css" media="all"/>
    <link rel="stylesheet" href="/css/public.css" media="all"/>
    
</head>
<body class="childrenBody">

<form class="layui-form">
    <blockquote class="layui-elem-quote quoteBox">
        <form class="layui-form">
            <div class="layui-inline">
                <div class="layui-input-inline">
                    <input type="text" class="layui-input searchVal" placeholder="请输入账号或昵称" />
                </div>
                <a class="layui-btn search_btn" data-type="reload">搜索</a>
            </div>
        </form>
    </blockquote>
    <table id="usersList" lay-filter="usersList"></table>
    <!--操作-->
</form>

<script type="text/javascript" src="/layui/layui.js"></script>

<script>
    layui.use(['form','layer','table'],function(){
        var form = layui.form,
            layer = parent.layer === undefined ? layui.layer : top.layer,
            $ = layui.jquery, table = layui.table;

        //用户列表
        var tableIns = table.render({
            elem: '#usersList',
            url : "<?php echo url('/admin/memberParent'); ?>"+'?uid='+"<?php echo htmlentities($_GET['uid']); ?>",
            cellMinWidth : 95,
            page : true,
            limit:10,
            limits:[5,10,15,20],
            height : "full-125",
            id:'usersListTable',
            cols : [[
                {field: 'id', title: 'id', width:60, align:"center"},
                {field: 'account', title: '账号',align:"center"},
                {field: 'nickname', title: '昵称', align:'center'},
                {field: 'title', title: '会员级别',  align:'center'},
                {field: 'moneys', title: '会员余额',  align:'center'},
                {field: 'commission', title: '会员佣金',  align:'center'},
                {field: 'parent_count', title: '团队人数',  align:'center'},
                {
                    field: 'is_prohibit', title: '是否禁用', align: 'center', width: 100, templet: function (d) {
                        if (d.is_prohibit == 1) {
                            return '<input type="checkbox" name="status"  checked="checked"  lay-filter="status" value="' + d.id + '" lay-skin="switch" lay-text="是|否" ' + d.is_prohibit + ' >'
                        } else {
                            return '<input type="checkbox" name="status" lay-filter="status" value="' + d.id + '" lay-skin="switch" lay-text="是|否" ' + d.is_prohibit + ' >'
                        }
                    }
                },
            ]]
        });

        //搜索【此功能需要后台配合，所以暂时没有动态效果演示】
        $(".search_btn").on("click",function(){
            table.reload("usersListTable",{
                page: {
                    curr: 1 //重新从第 1 页开始
                },
                where: {
                    key: $(".searchVal").val()  //搜索的关键字
                }
            })
        });


                        //修改用户组状态
        form.on('switch(status)', function (data) {
            var index = layer.msg('修改中，请稍后', {icon: 16, time: false, shade: 0.8});
            setTimeout(function () {
                layer.close(index);
                var status = data.elem.checked ? 1 : 0;
                id = data.elem.value;
                $.post("<?php echo url('/admin/memberProhibit'); ?>", {id: id, status: status}, function (data) {
                    var icon = 5;
                    if (data.code) {
                        icon = 6;
                    }
                    layer.msg(data.msg, {icon: icon, time: 1500});
                });
            }, 500);
        });

        //列表操作
        table.on('tool(usersList)', function(obj){
            var layEvent = obj.event, data = obj.data;
            if(layEvent === 'edit'){ //编辑
                edit(data.id,data.parent_id);
            } else if(layEvent === 'plist'){ //编辑
                plist(data.id,data.parent_id);
            }else if(layEvent === 'del'){ //删除
                layer.confirm('确定删除操作？',{icon:3, title:'提示信息'},function(index){
                    $.post("<?php echo url('/admin/delete'); ?>",{uid:data.uid},function(data){
                        var icon=5;
                        if(data.code){
                            icon=6;
                        }
                        layer.msg(data.msg, {icon:icon,time: 1500}, function () {
                            if(data.code){
                                obj.del();
                            }
                        });
                    })
                });
            }
        });

    })
</script>

</body>
</html>