<?php /*a:2:{s:78:"D:\phpstudy_pro\WWW\ein04\application\admin\view\system\commission_config.html";i:1587973070;s:63:"D:\phpstudy_pro\WWW\ein04\application\admin\view\base\base.html";i:1571729646;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo htmlentities($site_config['value']['title']); ?></title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="format-detection" content="telephone=no">
    <link rel="stylesheet" href="/layui/css/layui.css" media="all"/>
    <link rel="stylesheet" href="/css/public.css" media="all"/>
    
</head>
<body class="childrenBody">

<fieldset class="layui-elem-field layui-field-title">
    <legend>佣金配置</legend>
</fieldset>
<div class="layui-row layui-tab-content">
    <div class="layui-col-md6">
        <form class="layui-form layui-form-pane" action="">
            <div class="layui-form-item">
                <label class="layui-form-label">佣金比例</label>
                <div class="layui-input-block">
                    <input type="text" name="commission_rate" required lay-verify="required" placeholder="请输入佣金比例"
                           value="<?php echo htmlentities($data['value']['commission_rate']); ?>" autocomplete="off" class="layui-input">
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label">庄家余额</label>
                <div class="layui-input-block">
                    <input type="text" name="dealer_balance" required lay-verify="required" placeholder="庄家余额大于等于2000"
                           value="<?php echo htmlentities($data['value']['dealer_balance']); ?>" autocomplete="off" class="layui-input">
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label">结算手续费</label>
                <div class="layui-input-block">
                    <input type="text" name="settlement_fee" required lay-verify="required" placeholder="请输入结算手续费"
                           value="<?php echo htmlentities($data['value']['settlement_fee']); ?>" autocomplete="off" class="layui-input">
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label">庄家盈利</label>
                <div class="layui-input-block">
                    <input type="text" name="banker_profit" required lay-verify="required" placeholder="请输入庄家盈利"
                           value="<?php echo htmlentities($data['value']['banker_profit']); ?>" autocomplete="off" class="layui-input">
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label">每轮下注</label>
                <div class="layui-input-block">
                    <input type="text" name="bottom_pour" required lay-verify="required" placeholder="请输入每轮下注比例"
                           value="<?php echo htmlentities($data['value']['bottom_pour']); ?>" autocomplete="off" class="layui-input">
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label">提现手续费</label>
                <div class="layui-input-block">
                    <input type="text" name="withdraw_commission" required lay-verify="required" placeholder="请输入提现手续费比例"
                           value="<?php echo htmlentities($data['value']['withdraw_commission']); ?>" autocomplete="off" class="layui-input">
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label">客服QQ</label>
                <div class="layui-input-block">
                    <input type="text" name="QQ" required lay-verify="required" placeholder="请输入版权信息"
                           value="<?php echo htmlentities($data['value']['QQ']); ?>"  autocomplete="off"
                           class="layui-input">
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label">客服微信</label>
                <div class="layui-input-block">
                    <input type="text" name="wechat" required lay-verify="required" placeholder="请输入版权信息"
                           value="<?php echo htmlentities($data['value']['wechat']); ?>" autocomplete="off"
                           class="layui-input">
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-input-block">
                    <a class="layui-btn" lay-submit lay-filter="save">立即提交</a>
                </div>
            </div>
        </form>
    </div>
</div>



<script type="text/javascript" src="/layui/layui.js"></script>

<script>
    layui.use(['form', 'jquery'], function () {
        var form = layui.form;
        var $ = layui.jquery;
        //监听提交
        form.on('submit(save)', function (data) {
            var obj = $(this);
            obj.attr("disabled", "disabled").addClass("layui-disabled");
            $.post("<?php echo url('/admin/commissionConfig'); ?>", data.field, function (data) {
                var icon = 5;
                if (data.code) {
                    icon = 6;
                }
                layer.msg(data.msg, {icon: icon, time: 1500}, function () {
                    if (data.code) {
                        location.reload();
                    } else {
                        obj.removeAttr("disabled").removeClass("layui-disabled");
                    }
                });
            });
            return false;
        });
    });
</script>

</body>
</html>