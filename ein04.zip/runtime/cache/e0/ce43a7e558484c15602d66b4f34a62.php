<?php
//000000000000
 exit();?>
D:\phpstudy_pro\WWW\ein04\runtime\cache\62\431c332e39150791959619bcd167cd.php