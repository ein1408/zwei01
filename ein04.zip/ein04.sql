/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50726
Source Host           : localhost:3306
Source Database       : ein04

Target Server Type    : MYSQL
Target Server Version : 50726
File Encoding         : 65001

Date: 2020-04-28 11:10:16
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for think_auth_group
-- ----------------------------
DROP TABLE IF EXISTS `think_auth_group`;
CREATE TABLE `think_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` char(100) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态：为1正常，为0禁用',
  `rules` char(80) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id， 多个规则","隔开',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of think_auth_group
-- ----------------------------
INSERT INTO `think_auth_group` VALUES ('1', '管理员组', '0', '1,2,3,4,5,6,8,9,10', '0', '1494407780');
INSERT INTO `think_auth_group` VALUES ('2', '普通用户组', '0', '1,2,3,4,10,13,14,18,19', '0', '1494308736');

-- ----------------------------
-- Table structure for think_auth_group_access
-- ----------------------------
DROP TABLE IF EXISTS `think_auth_group_access`;
CREATE TABLE `think_auth_group_access` (
  `uid` mediumint(8) unsigned NOT NULL COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组id',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of think_auth_group_access
-- ----------------------------
INSERT INTO `think_auth_group_access` VALUES ('1', '1');
INSERT INTO `think_auth_group_access` VALUES ('2', '2');

-- ----------------------------
-- Table structure for think_auth_rule
-- ----------------------------
DROP TABLE IF EXISTS `think_auth_rule`;
CREATE TABLE `think_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一标识',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文名称',
  `pid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '父级ID',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态：为1正常，为0禁用',
  `condition` char(100) NOT NULL DEFAULT '' COMMENT '规则表达式，为空表示存在就验证，不为空表示按照条件验证',
  `menu` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否是菜单；0:否，1:是',
  `icon` varchar(255) DEFAULT NULL COMMENT '菜单图标',
  `sort` int(11) unsigned NOT NULL DEFAULT '1' COMMENT '排序',
  PRIMARY KEY (`id`),
  KEY `name` (`name`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of think_auth_rule
-- ----------------------------
INSERT INTO `think_auth_rule` VALUES ('1', '#', '首页', '0', '1', '1', '', '1', 'layui-icon layui-icon-home', '2');
INSERT INTO `think_auth_rule` VALUES ('2', '#', '用户管理', '0', '1', '1', '', '1', 'layui-icon layui-icon-user', '2');
INSERT INTO `think_auth_rule` VALUES ('3', 'admin/userList', '用户列表', '2', '1', '1', '', '1', null, '1');
INSERT INTO `think_auth_rule` VALUES ('4', 'admin/groupList', '用户组列表', '2', '1', '1', '', '1', null, '1');
INSERT INTO `think_auth_rule` VALUES ('5', 'admin/edit', '添加用户', '2', '1', '1', '', '0', '', '1');
INSERT INTO `think_auth_rule` VALUES ('6', '#', '系统管理', '0', '1', '1', '', '1', 'layui-icon layui-icon-set', '1');
INSERT INTO `think_auth_rule` VALUES ('7', 'admin/cleanCache', '清除缓存', '6', '1', '1', '', '1', '', '1');
INSERT INTO `think_auth_rule` VALUES ('8', 'admin/menu', '菜单管理', '6', '1', '1', '', '1', '', '1');
INSERT INTO `think_auth_rule` VALUES ('9', 'admin/home', '系统信息', '1', '1', '1', '', '1', '', '1');
INSERT INTO `think_auth_rule` VALUES ('10', 'admin/log', '日志管理', '6', '1', '1', '', '1', '', '1');
INSERT INTO `think_auth_rule` VALUES ('11', 'admin/editMenu', '编辑菜单', '6', '1', '1', '', '0', '', '1');
INSERT INTO `think_auth_rule` VALUES ('12', 'admin/deleteMenu', '删除菜单', '6', '1', '1', '', '0', '', '1');
INSERT INTO `think_auth_rule` VALUES ('13', 'admin/config', '系统配置', '6', '1', '1', '', '1', '', '1');
INSERT INTO `think_auth_rule` VALUES ('14', 'admin/siteConfig', '站点配置', '6', '1', '1', '', '1', '', '1');
INSERT INTO `think_auth_rule` VALUES ('15', 'admin/editGroup', '添加编辑用户组', '2', '1', '1', '', '0', '', '1');
INSERT INTO `think_auth_rule` VALUES ('16', 'admin/disableGroup', '禁用用户组', '2', '1', '1', '', '0', '', '1');
INSERT INTO `think_auth_rule` VALUES ('17', 'admin/ruleList', '规则列表', '2', '1', '1', '', '0', '', '1');
INSERT INTO `think_auth_rule` VALUES ('18', 'admin/editRule', '修改规则', '2', '1', '1', '', '0', '', '1');
INSERT INTO `think_auth_rule` VALUES ('19', 'admin/memberList', '会员列表', '2', '1', '1', '', '1', '', '1');
INSERT INTO `think_auth_rule` VALUES ('20', 'admin/memberEdit', '添加会员', '2', '1', '1', '', '0', '', '1');
INSERT INTO `think_auth_rule` VALUES ('21', 'admin/memberLevel', '会员级别', '2', '1', '1', '', '1', '', '1');
INSERT INTO `think_auth_rule` VALUES ('22', 'admin/levelEdit', '添加等级', '2', '1', '1', '', '0', '', '1');
INSERT INTO `think_auth_rule` VALUES ('23', 'admin/commissionConfig', '佣金配置', '6', '1', '1', '', '1', '', '1');
INSERT INTO `think_auth_rule` VALUES ('24', 'admin/memberParent', '查看下级', '2', '1', '1', '', '0', '', '1');
INSERT INTO `think_auth_rule` VALUES ('25', '#', '财务报表', '0', '1', '1', '', '1', 'layui-icon layui-icon-rmb', '2');
INSERT INTO `think_auth_rule` VALUES ('26', 'admin/userBill', '报表明细', '25', '1', '1', '', '1', '', '1');
INSERT INTO `think_auth_rule` VALUES ('27', 'admin/recharge', '充值/提现', '25', '1', '1', '', '1', '', '1');
INSERT INTO `think_auth_rule` VALUES ('28', 'admin/noticeConfig', '公告', '6', '1', '1', '', '1', '', '1');

-- ----------------------------
-- Table structure for think_config
-- ----------------------------
DROP TABLE IF EXISTS `think_config`;
CREATE TABLE `think_config` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(255) NOT NULL COMMENT '配置字段名',
  `title` varchar(255) NOT NULL COMMENT '配置标题名称',
  `value` text NOT NULL COMMENT '配置参数',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of think_config
-- ----------------------------
INSERT INTO `think_config` VALUES ('1', 'system_config', '系统配置', '{\"debug\": \"0\", \"trace\": \"0\", \"trace_type\": \"0\"}', '0', '1523414007', '1531729547');
INSERT INTO `think_config` VALUES ('2', 'site_config', '站点配置', '{\"title\":\"originThink\",\"name\":\"originThink\",\"copyright\":\"copyright @2018 originThink\",\"icp\":\"苏ICP备0000000号\"}', '1', '1523414007', '1587973478');
INSERT INTO `think_config` VALUES ('3', 'commission_config', '佣金配置', '{\"commission_rate\":\"3\",\"dealer_balance\":\"2000\",\"settlement_fee\":\"8\",\"banker_profit\":\"8\",\"bottom_pour\":\"8\",\"withdraw_commission\":\"1\",\"QQ\":\"2120202\",\"wechat\":\"98100500\"}', '1', '1', '1587973457');
INSERT INTO `think_config` VALUES ('4', 'notice_config', '公告配置', '{\"notice\":\"dasd\",\"status\":1}', '1', '1588037761', '1588037761');

-- ----------------------------
-- Table structure for think_login_log
-- ----------------------------
DROP TABLE IF EXISTS `think_login_log`;
CREATE TABLE `think_login_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `uid` int(11) unsigned NOT NULL COMMENT '用户id',
  `user` varchar(255) NOT NULL COMMENT '账号',
  `name` varchar(255) NOT NULL COMMENT '用户名',
  `last_login_ip` varchar(32) NOT NULL COMMENT '登录ip',
  `create_time` int(11) unsigned NOT NULL COMMENT '登录时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of think_login_log
-- ----------------------------
INSERT INTO `think_login_log` VALUES ('1', '1', 'admin', 'admin', '127.0.0.1', '1587891501');
INSERT INTO `think_login_log` VALUES ('2', '1', 'admin', 'admin', '127.0.0.1', '1587950202');
INSERT INTO `think_login_log` VALUES ('3', '1', 'admin', 'admin', '127.0.0.1', '1587956763');
INSERT INTO `think_login_log` VALUES ('4', '1', 'admin', 'admin', '127.0.0.1', '1588036804');

-- ----------------------------
-- Table structure for think_member
-- ----------------------------
DROP TABLE IF EXISTS `think_member`;
CREATE TABLE `think_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nickname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '昵称',
  `level_id` int(10) NOT NULL COMMENT '级别id',
  `parent_id` int(11) DEFAULT NULL COMMENT '父类id',
  `unicode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '唯一值',
  `account` bigint(20) DEFAULT NULL COMMENT '账号',
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '密码',
  `commission` double NOT NULL COMMENT '会员佣金',
  `moneys` double NOT NULL,
  `is_prohibit` tinyint(4) NOT NULL COMMENT '是否禁用',
  `parent_count` int(11) NOT NULL COMMENT '团队人数',
  `headpic` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '头像',
  `is_agent` tinyint(4) DEFAULT NULL COMMENT '是否代理',
  PRIMARY KEY (`id`),
  KEY `level_id` (`level_id`) USING HASH,
  KEY `parent_id` (`parent_id`) USING HASH
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of think_member
-- ----------------------------
INSERT INTO `think_member` VALUES ('1', 'zf', '6', '0', '1156161', '13229744532', null, '0', '2000', '0', '1', null, null);
INSERT INTO `think_member` VALUES ('2', 'zf01', '6', '1', '1056161', '1085215630', null, '163', '100', '0', '0', null, null);

-- ----------------------------
-- Table structure for think_member_bill
-- ----------------------------
DROP TABLE IF EXISTS `think_member_bill`;
CREATE TABLE `think_member_bill` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL COMMENT '用户id',
  `pm` tinyint(4) NOT NULL COMMENT '0是支出，1是获取',
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '获取的标题',
  `type` tinyint(4) DEFAULT NULL COMMENT '支付类型1.佣金2抽成8提现9充值',
  `number` double DEFAULT NULL COMMENT '支出或获取金额',
  `balance` double DEFAULT NULL COMMENT '用户余额',
  `add_time` bigint(20) DEFAULT NULL COMMENT '增加时间',
  `status` tinyint(4) DEFAULT NULL COMMENT '0 = 带确定 1 = 有效 -1 = 无效',
  `orderid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '订单号',
  `mark` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '详细明细',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of think_member_bill
-- ----------------------------
INSERT INTO `think_member_bill` VALUES ('1', '2', '1', '推荐佣金', '1', '100', '100', '1587981471', '1', '1587981471', null);
INSERT INTO `think_member_bill` VALUES ('2', '2', '0', '佣金提现', '8', '100', '100', '1587981471', '0', '1587981471', null);
INSERT INTO `think_member_bill` VALUES ('3', '2', '1', '推荐佣金', '1', '9', '100', '1588041522', '1', '1588041522', '推荐佣金');
INSERT INTO `think_member_bill` VALUES ('4', '2', '1', '推荐佣金', '1', '9', '100', '1588041600', '1', '1588041600', '获取下注金额的佣金');

-- ----------------------------
-- Table structure for think_member_level
-- ----------------------------
DROP TABLE IF EXISTS `think_member_level`;
CREATE TABLE `think_member_level` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '级别名称',
  `proportion` int(11) NOT NULL COMMENT '百分比',
  `status` tinyint(4) NOT NULL COMMENT '是否关闭这个级别',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of think_member_level
-- ----------------------------
INSERT INTO `think_member_level` VALUES ('1', 'v1', '1', '0');
INSERT INTO `think_member_level` VALUES ('2', 'V2', '1', '0');
INSERT INTO `think_member_level` VALUES ('3', 'V3', '1', '0');
INSERT INTO `think_member_level` VALUES ('4', 'V4', '1', '0');
INSERT INTO `think_member_level` VALUES ('5', 'v5', '1', '0');
INSERT INTO `think_member_level` VALUES ('6', 'v6', '2', '0');
INSERT INTO `think_member_level` VALUES ('7', 'V7', '2', '0');
INSERT INTO `think_member_level` VALUES ('8', 'V8', '2', '0');
INSERT INTO `think_member_level` VALUES ('9', 'V9', '3', '0');
INSERT INTO `think_member_level` VALUES ('10', '牛牛', '4', '0');
INSERT INTO `think_member_level` VALUES ('11', '特殊', '5', '0');
INSERT INTO `think_member_level` VALUES ('12', '庄家', '0', '0');

-- ----------------------------
-- Table structure for think_user
-- ----------------------------
DROP TABLE IF EXISTS `think_user`;
CREATE TABLE `think_user` (
  `uid` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user` varchar(32) NOT NULL COMMENT '账号',
  `name` varchar(255) NOT NULL COMMENT '用户名',
  `head` varchar(255) DEFAULT NULL COMMENT '头像',
  `password` varchar(255) NOT NULL COMMENT '密码',
  `login_count` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '登录次数',
  `last_login_ip` varchar(32) NOT NULL DEFAULT '0.0.0.0' COMMENT '最后登录ip地址',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否禁用；0: 禁用 1:正常',
  `updatapassword` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `user_unique` (`user`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of think_user
-- ----------------------------
INSERT INTO `think_user` VALUES ('1', 'admin', 'admin', null, '$2y$10$HLh4UHoluqLvwsNN6vQxz.tuKMA5xYp6rH2vOpA.74sxiQbjwm2My', '91', '127.0.0.1', '1588036804', '1', '1', '0', '1588036804');
INSERT INTO `think_user` VALUES ('2', 'admin1', 'admin1', null, '$2y$10$HLh4UHoluqLvwsNN6vQxz.tuKMA5xYp6rH2vOpA.74sxiQbjwm2My', '13', '127.0.0.1', '1535891091', '1', '1', '0', '1535891091');

-- ----------------------------
-- Table structure for tkink_redpacket_log
-- ----------------------------
DROP TABLE IF EXISTS `tkink_redpacket_log`;
CREATE TABLE `tkink_redpacket_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '抢红包用户id（多个用户用逗号隔开）',
  `moneys` double DEFAULT NULL COMMENT '红包金额',
  `number` int(11) DEFAULT NULL COMMENT '人数',
  `add_time` bigint(20) DEFAULT NULL COMMENT '时间',
  `type` tinyint(4) DEFAULT NULL COMMENT '1为发红包2为抢红包',
  `orderid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '订单id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of tkink_redpacket_log
-- ----------------------------
