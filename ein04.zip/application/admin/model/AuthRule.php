<?php
/**
 * Created by originThink
 * Author: 原点 467490186@qq.com
 * Date: 2018/11/27
 * Time: 17:58
 */

namespace app\admin\model;

use think\Model;

class AuthRule extends Model
{

}