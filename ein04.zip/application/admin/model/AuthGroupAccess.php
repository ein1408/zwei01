<?php
/**
 * Created by originThink
 * Author: 原点 467490186@qq.com
 * Date: 2017/5/5
 * Time: 14:02
 */

namespace app\admin\model;

use think\Model;

class AuthGroupAccess extends Model
{

}